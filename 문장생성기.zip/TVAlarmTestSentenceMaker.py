FINAL_TEXT_TITLE = 'TV 예약 질의 테스트.txt'
text_list = ['TV 예약 명사 질의 테스트.txt', 'TV 예약 동사 질의 테스트.txt', 'TV 예약 도치 질의 테스트.txt']
adverb_list = ['', '예약된', '예약했었던']

time_list = ['', '오늘',  '다음주',  '오후에'] # '다음주 오전에', '내일 오전에', '오늘 오전에'
time_list2 = [str(i) + '시에' for i in range(2, 24, 10)] # 시간을 일부만 사용하자
time_list3 = [str(i) + '시에' for i in range(3, 12, 6)] # 시간을 일부만 사용하자
time_list4 = [str(i) + '일 뒤에' for i in range(2, 7, 4)] # 시간을 일부만 사용하자
am_pm_list = ['오전', '오후']

object_list = ['프로들', '프로그램', '것들']
object_list2 = ['프로를', '프로그램을',  '방송을']
object_list3 = ['리스트', '전체', '모두']
subject_list = ['테레비에', 'TV에서']  # '테레비에', 'TV에서'
subject_list2 = ['TV가', '테레비가', '텔레비전이']
subject_list3 = ['', 'TV에', '테레비에', '텔레비전에']

additional_list = ['상태', '상황', '전원']
verb_list = ['예약했니', '예약했지', '예약했었냐', '예약한건가']   # 테스트는 안 붙여서... 하면 너무 많아짐
verb_list2 = ['있지', '없나', '있었니', '없었나']
verb_list3 = ['예약 되었지', '예약 안 돼 있냐', '예약 안 돼 있는가']
verb_list4 = ['보여 줘', '띄워 줘']

# 현재 집에서 TV 동작 중이니? -> test
# time + subject + object


def noun_plain_sentence_generator():
    for subject_ in subject_list:
        for object_ in object_list:
            for adverb_ in adverb_list:
                if adverb_ != '':
                    for time_ in time_list:
                        if subject_ != '' and time_ != '': # 중복문 만들어지는 조건이 아니면.
                            yield subject_ + ' ' + time_ + ' ' + adverb_ + ' ' + object_ + '\n'
                            yield time_ + ' ' + subject_ + ' ' + adverb_ + ' ' + object_ + '\n'
                        elif time_ == '' and subject_ == '':
                            if object_ != object_list[-1]:
                                yield adverb_ + ' ' + object_ + '\n'
                        elif subject_ == '':
                            yield time_ + ' ' + adverb_ + ' ' + object_ + '\n'
                        else:
                            yield subject_ + ' ' + adverb_ + ' ' + object_ + '\n'

                    for time_ in time_list2:
                        if subject_ != '' and time_ != '':  # 중복문 만들어지는 조건이 아니면.
                            yield subject_ + ' ' + time_ + ' ' + adverb_ + ' ' + object_ + '\n'
                            yield time_ + ' ' + subject_ + ' ' + adverb_ + ' ' + object_ + '\n'
                        elif subject_ == '' and time_ != '':
                            yield time_ + ' ' + adverb_ + ' ' + object_ + '\n'

                    for time_ in time_list3:
                        for am_pm in am_pm_list:
                            if subject_ != '' and time_ != '':  # 중복문 만들어지는 조건이 아니면.
                                yield subject_ + ' ' + am_pm + ' ' + time_ + ' ' + adverb_ + ' ' + object_ + '\n'
                                yield am_pm + ' ' + time_ + ' ' + subject_ + ' ' + adverb_ + ' ' + object_ + '\n'
                            elif subject_ == '' and time_ != '':
                                yield time_ + ' ' + adverb_ + ' ' + object_ + '\n'

                    for time_ in time_list4:
                        if subject_ != '' and time_ != '':  # 중복문 만들어지는 조건이 아니면.
                            yield subject_ + ' ' + time_ + ' ' + adverb_ + ' ' + object_ + '\n'
                            yield time_ + ' ' + subject_ + ' ' + adverb_ + ' ' + object_ + '\n'
                        elif subject_ == '' and time_ != '':
                            yield time_ + ' ' + adverb_ + ' ' + object_ + '\n'


def verb_plain_sentence_generator():
    for adverb_ in adverb_list:
        for object_ in object_list2:
            for subject_ in subject_list3:
                for verb_ in verb_list:
                    for time_ in time_list:
                        if subject_ != '' and time_ != '':
                            yield subject_ + ' ' + time_ + ' ' + object_ + ' ' + verb_ + '\n'
                            yield time_ + ' ' + subject_ + ' ' + object_ + ' ' + verb_ + '\n'
                        elif time_ == '' and subject_ == '':
                            yield object_ + ' ' + verb_ + '\n'
                        elif subject_ == '':
                            yield time_ + ' ' + object_ + ' ' + verb_ + '\n'
                        else:
                            yield subject_ + ' ' + object_ + ' ' + verb_ + '\n'

                    for time_ in time_list2:
                        if subject_ != '' and time_ != '':
                            yield subject_ + ' ' + time_ + ' ' + object_ + ' ' + verb_ + '\n'
                            yield time_ + ' ' + subject_ + ' ' + object_ + ' ' + verb_ + '\n'
                        elif subject_ == '' and time_ != '':
                            yield time_ + ' ' + object_ + ' ' + verb_ + '\n'

                    for time_ in time_list3:
                        for am_pm in am_pm_list:
                            if subject_ != '' and time_ != '':
                                yield subject_ + ' ' + am_pm + ' ' + time_ + ' ' + object_ + ' ' + verb_ + '\n'
                                yield am_pm + ' ' + time_ + ' ' + subject_ + ' ' + object_ + ' ' + verb_ + '\n'
                            elif subject_ == '' and time_ != '':
                                yield am_pm + ' ' + time_ + ' ' + object_ + ' ' + verb_ + '\n'

                    for time_ in time_list4:
                        if subject_ != '' and time_ != '':
                            yield subject_ + ' ' + time_ + ' ' + object_ + ' ' + verb_ + '\n'
                            yield time_ + ' ' + subject_ + ' ' + object_ + ' ' + verb_ + '\n'
                        elif subject_ == '' and time_ != '':
                            yield time_ + ' ' + object_ + ' ' + verb_ + '\n'

                if adverb_ != '':
                    for verb_ in verb_list2:
                        for time_ in time_list:
                            if time_ != '' and subject_ != '':
                                yield subject_ + ' ' + time_ + adverb_ + ' ' + object_ + ' ' + verb_ + '\n'
                                yield time_ + ' ' + subject_ + adverb_ + ' ' + object_ + ' ' + verb_ + '\n'
                            elif time_ != '':
                                subject_ + adverb_ + ' ' + object_ + ' ' + verb_ + '\n'
                            else:
                                yield adverb_ + ' ' + object_ + ' ' + verb_ + '\n'

                        for time_ in time_list2:
                            if time_ != '' and subject_ != '':
                                yield subject_ + ' ' + time_ + ' ' + adverb_ + ' ' + object_ + ' ' + verb_ + '\n'
                                yield time_ + ' ' + subject_ + ' ' + adverb_ + ' ' + object_ + ' ' + verb_ + '\n'

                        for time_ in time_list3:
                            for am_pm in am_pm_list:
                                if time_ != '' and subject_ != '':
                                    yield subject_ + ' ' + am_pm + ' ' + time_ + ' ' + adverb_ + ' ' + object_ + ' ' + verb_ + '\n'
                                    yield am_pm + ' ' + time_ + ' ' + subject_ + ' ' + adverb_ + ' ' + object_ + ' ' + verb_ + '\n'

                        for time_ in time_list4:
                            if time_ != '' and subject_ != '':
                                yield subject_ + ' ' + time_ + ' ' + adverb_ + ' ' + object_ + ' ' + verb_ + '\n'
                                yield time_ + ' ' + subject_ + ' ' + adverb_ + ' ' + object_ + ' ' + verb_ + '\n'

        if adverb_ != '':
            for verb_ in verb_list4:
                for object_ in object_list:
                    for object2_ in object_list3:
                        for subject_ in subject_list:
                            if subject_ != '':
                                yield subject_ + ' ' + adverb_ + ' ' + object_ + ' ' + object2_ + ' ' + verb_ + '\n'
                            else:
                                yield adverb_ + ' ' + object_ + ' ' + object2_ + ' ' + verb_ + '\n'


def inversion_sentence_generator():
    for adverb_ in adverb_list:
        if adverb_ != '':
            for object_ in object_list:
                for subject_ in subject_list3[1:]:
                    for verb_ in verb_list2:
                        yield adverb_ + ' ' + object_ + ' ' + subject_ + ' ' + verb_ + '\n'
        else:
            for verb_ in verb_list3:
                for object_ in object_list2[:-2]:
                    for subject_ in subject_list3:
                        if subject_ != '':
                            yield object_ + ' ' + subject_ + ' ' + verb_ + '\n'


if __name__ == '__main__':
    #
    # 1. time + subject + object
    with open(text_list[0], 'w', encoding='utf-8') as f:
        gen = noun_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    with open(text_list[1], 'w', encoding='utf-8') as f:
        gen = verb_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)
    #
    # 2. time + object + subject + additional
    with open(text_list[2], 'w', encoding='utf-8') as f:
        gen = inversion_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    allQuestion = ''
    for text in text_list:
        with open(text, 'r', encoding='utf-8') as f:
            allQuestion = allQuestion + f.read()

    with open(FINAL_TEXT_TITLE, 'w', encoding='utf-8') as f:
        f.write(allQuestion)