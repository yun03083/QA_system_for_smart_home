FILE_NAME_LIST = ['TV 예약 질의 테스트.txt', 'TV 예약 질의 테스트.txt', 'TV 편성표 질의 테스트.txt',\
                  '전구 전원 질의 테스트.txt', '전구 밝기 질의 테스트.txt', '전구 위치 밝기 질의 테스트.txt', \
                  '전구 색상 질의 테스트.txt', '전구 위치 색상 질의 테스트.txt', '전구 설정 질의 테스트.txt', \
                  '전기 날짜 질의 테스트.txt', '전기 기간 질의 테스트.txt']

if __name__ == '__main__':
    label = 0
    result = ""
    for file in FILE_NAME_LIST:
        with open(file, 'r', encoding='utf-8') as f:
            data = f.read()
            data = data.replace('\n', ' ' + str(label) + '\n')
            result = result + data
            label = label + 1

    with open('labled_text_test.txt', 'w', encoding='utf-8') as f:
        f.write(result)



