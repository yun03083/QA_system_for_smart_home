FINAL_TEXT_TITLE = '전기 날짜 질의.txt'
text_list = ['전기 날짜 명사 질의.txt', '전기 날짜 동사 질의.txt']

electricity_list = ['전기', '전기료', '전기 요금', '전기 사용량', '전기 요금과 전기 사용량', '전기 사용량이랑 전기 요금', '전기 사용량과 전기 요금', '전기료와 전기 사용량', '전기 사용량이랑 전기료', '전기 사용량과 전기료']
target_date_list = ['이번달', '저번달', '이번달의', '저번달의', '2개월 전의', '3개월 전의', '6개월 전의', '5월', '6월', '1월', '2월', '5월의', '6월의', '4월의', '3월의']
information_list1 = ['정보', '정보는', '정보들', '정보들은', '정보 조회', '조회']
information_list2 = ['정보', '정보들']
information_list3 = ['정보', '정보들', '정보는', '정보들은', '것', '것들', '것은', '것들은']
verb_list = [
    '보여 줘', '얼마나 썼는지 알려 줘', '얼마나 썼니', '얼마나 썼었니', '얼마나 썼냐', '얼마나 썼었냐',\
    '어떠니', '어떤지', '어떻게 되지', '어떻게 되나', '어떻게 되는지', '어떻게 되었지', '뭐지', '뭐야', \
    '얼마나 돼', '얼마나 되니', '얼마나 되는지', '얼마지', '얼마야', '얼마니', '얼마냐', '얼마인지']


def noun_plain_sentence_generator():
    for date_ in target_date_list:
        for electricity_ in electricity_list:
            yield date_ + ' ' + electricity_ + '\n'

            for info_ in information_list1:
                yield date_ + ' ' + electricity_ + ' ' + info_ + '\n'

            for info_ in information_list3:
                yield electricity_ + ' ' + date_ + ' ' + info_ + '\n'


def verb_plain_sentence_generator():
    for date_ in target_date_list:
        for electricity_ in electricity_list:
            for verb_ in verb_list:
                yield date_ + ' ' + electricity_ + ' ' + verb_ + '\n'

                for info_ in information_list2:
                    yield electricity_ + ' ' + date_ + ' ' + info_ + ' ' + verb_ + '\n'



if __name__ == '__main__':
    #
    # 1. time + subject + object
    with open(text_list[0], 'w', encoding='utf-8') as f:
        gen = noun_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    with open(text_list[1], 'w', encoding='utf-8') as f:
        gen = verb_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)
    # #
    # # 2. time + object + subject + additional
    # with open(text_list[2], 'w', encoding='utf-8') as f:
    #     gen = inversion_sentence_generator()
    #     for sentence in gen:
    #         f.write(sentence)
    #
    allQuestion = ''
    for text in text_list:
        with open(text, 'r', encoding='utf-8') as f:
            allQuestion = allQuestion + f.read()

    with open(FINAL_TEXT_TITLE, 'w', encoding='utf-8') as f:
        f.write(allQuestion)