FILE_NAME = 'labled_text.txt'

if __name__ == '__main__':

    with open(FILE_NAME, 'r', encoding='utf-8') as f:
        data = list(f.readlines())
        for i in range(len(data)):
            data[i] = str(i) + ' ' + data[i]

    with open('case_train.txt', 'w', encoding='utf-8') as f:
        for dt in data:
            f.write(dt)
