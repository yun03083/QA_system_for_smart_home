FINAL_TEXT_TITLE = '전구 색상 밝기 질의.txt'
text_list = ['전구 색상 명사 질의.txt', '전구 색상 동사 질의.txt']



lamp_list = ['등', '불', '전구', '불들', '전구들']  # A '전구 불', '전구 등', '등불'
location_list = ['집에', '각각의', '각']  # B

color_list = ['색', '컬러', '색상', '색상들'] # D '색들', '컬러들'
search_list = ['설정', '정보', '설정 값', '정보 값', '조회', '정보 조회'] # E '설정 조회', '설정 정보 조회', '값 조회', '값 정보 조회'

time_list = ['지금', '현재', '현재 시점에서', '현재 상황에서'] # '현 시점에서', '현 상황에서'

# F
verb_list = ['뭐야', '뭐지', '뭐냐', '어떻지', '어떠니', '어때', '알려 줘', '보여 줘', '뭐 일까'] # '보여 줄래', '뭔지', '뭘까', '어떤지', '알려 줄래'


def noun_plain_sentence_generator():
    for lamp_ in lamp_list:
        for color_ in color_list:
            yield lamp_ + ' ' + color_ + '\n'
            yield lamp_ + '의 ' + color_ + '\n'

            for search_ in search_list:
                yield lamp_ + ' ' + color_ + ' ' + search_ + '\n'
                yield lamp_ + '의 ' + color_ + ' ' + search_ + '\n'

                for target_location_ in location_list:
                    yield target_location_ + ' ' + lamp_ + ' ' + color_ + '\n'
                    yield target_location_ + ' ' + lamp_ + '의 ' + color_ + '\n'
                    yield target_location_ + ' ' + lamp_ + ' ' + color_ + ' ' + search_ + '\n'
                    yield target_location_ + ' ' + lamp_ + '의 ' + color_ + ' ' + search_ + '\n'

                    for time_ in time_list:
                        yield time_ + ' ' + target_location_ + ' ' + lamp_ + ' ' + color_ + '\n'
                        yield time_ + ' ' + target_location_ + ' ' + lamp_ + '의 ' + color_ + '\n'
                        yield time_ + ' ' + target_location_ + ' ' + lamp_ + ' ' + color_ + ' ' + search_ + '\n'
                        yield time_ + ' ' + target_location_ + ' ' + lamp_ + '의 ' + color_ + ' ' + search_ + '\n'


def verb_plain_sentence_generator():
    for lamp_ in lamp_list:
        for color_ in color_list:
            for verb_ in verb_list:
                yield lamp_ + ' ' + color_ + ' ' + verb_ + '\n'
                yield lamp_ + '의 ' + color_ + ' ' + verb_ + '\n'

                for target_location_ in location_list:
                    yield target_location_ + ' ' + lamp_ + ' ' + color_ + ' ' + verb_ + '\n'
                    yield target_location_ + ' ' + lamp_ + '의 ' + color_ + ' ' + verb_ + '\n'

                    for time_ in time_list:
                        yield time_ + ' ' + target_location_ + ' ' + lamp_ + ' ' + color_ + ' ' + verb_ + '\n'
                        yield time_ + ' ' + target_location_ + ' ' + lamp_ + '의 ' + color_ + ' ' + verb_ + '\n'





if __name__ == '__main__':
    #
    # 1. time + subject + object
    with open(text_list[0], 'w', encoding='utf-8') as f:
        gen = noun_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    with open(text_list[1], 'w', encoding='utf-8') as f:
        gen = verb_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)
    # #
    # # 2. time + object + subject + additional
    # with open(text_list[2], 'w', encoding='utf-8') as f:
    #     gen = inversion_sentence_generator()
    #     for sentence in gen:
    #         f.write(sentence)
    #
    allQuestion = ''
    for text in text_list:
        with open(text, 'r', encoding='utf-8') as f:
            allQuestion = allQuestion + f.read()

    with open(FINAL_TEXT_TITLE, 'w', encoding='utf-8') as f:
        f.write(allQuestion)