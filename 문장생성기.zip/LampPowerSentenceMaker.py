FINAL_TEXT_TITLE = '전구 전원 질의.txt'
text_list = ['전구 전원 명사 질의.txt', '전구 전원 동사 질의.txt']

lamp_list = ['등', '불', '전구', '전구 불', '전구 등', '등불']
time_list = ['지금', '현재'] # '현 시점에서', '현 상황에서'
location_adverb_list = ['집에', '집안에'] # '집 내부에'
human_adverb_list = ['누가', '누군가', '동생이', '형이', '누나가', '언니가', '어머니께서', '엄마가', '아버지께서', '아빠가'] # '여동생이', '남동생이', '태완이가', '윤태완이'
location_list = ['들어온 곳', '들어온 것', '들어온 데', '들어온 방', '켜진 곳', '켜진 데', '켜진 방'] # '켜져있는 곳', '켜져있는 데', '켜져있는 방'
verb_list = ['어디야', '어디니', '어디냐', '있어', '있니', '있냐', '알려 줘', '알려 줄래'] # '어디에 있니', '어디에 있어'
verb_list2 = ['켜졌어', '켜져있니', '켜놨어', '켰어', '꺼놨어', '껐어', '켰는지', '껐는지'] # '켜져있나' , '켜져있는지', '꺼져있는지', '꺼져있나'


def noun_plain_sentence_generator():
    for lamp_ in lamp_list:
        for location_ in location_list:
            yield lamp_ + ' ' + location_ + '\n'

            for adverb_ in location_adverb_list:
                yield adverb_ + ' ' + lamp_ + ' ' + location_ + '\n'

                for time_ in time_list:
                    yield time_ + ' ' + lamp_ + ' ' + location_ + '\n'
                    yield time_ + ' ' + adverb_ + ' ' + lamp_ + ' ' + location_ + '\n'


def verb_plain_sentence_generator():
    for verb_ in verb_list:
        for lamp_ in lamp_list:
            for location_ in location_list:
                yield lamp_ + ' ' + location_ + '\n'

                for adverb_ in location_adverb_list:
                    yield adverb_ + ' ' + lamp_ + ' ' + location_ + '\n'

                    for time_ in time_list:
                        yield time_ + ' ' + lamp_ + ' ' + location_ + '\n'
                        yield time_ + ' ' + adverb_ + ' ' + lamp_ + ' ' + location_ + '\n'

    for verb_ in verb_list2:
        for human_adverb_ in human_adverb_list:
            for lamp_ in lamp_list:
                yield human_adverb_ + ' ' + lamp_ + ' ' + verb_ + '\n'

                for location_adverb_ in location_adverb_list:
                    yield human_adverb_ + ' ' + location_adverb_ + ' ' + lamp_ + ' ' + verb_ + '\n'
                    for time_ in time_list:
                        yield human_adverb_ + ' ' + time_ + ' ' + lamp_ + ' ' + verb_ + '\n'
                        yield human_adverb_ + ' ' + time_ + ' ' + location_adverb_ + ' ' + lamp_ + ' ' + verb_ + '\n'
                        yield human_adverb_ + ' ' + location_adverb_ + ' ' + time_ + ' ' + lamp_ + ' ' + verb_ + '\n'


if __name__ == '__main__':
    #
    # 1. time + subject + object
    with open(text_list[0], 'w', encoding='utf-8') as f:
        gen = noun_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    with open(text_list[1], 'w', encoding='utf-8') as f:
        gen = verb_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)
    # #
    # # 2. time + object + subject + additional
    # with open(text_list[2], 'w', encoding='utf-8') as f:
    #     gen = inversion_sentence_generator()
    #     for sentence in gen:
    #         f.write(sentence)
    #
    allQuestion = ''
    for text in text_list:
        with open(text, 'r', encoding='utf-8') as f:
            allQuestion = allQuestion + f.read()

    with open(FINAL_TEXT_TITLE, 'w', encoding='utf-8') as f:
        f.write(allQuestion)