FINAL_TEXT_TITLE = '전구 설정 질의 테스트.txt'
text_list = ['전구 설정 명사 질의 테스트.txt', '전구 설정 동사 질의 테스트.txt']

lamp_setting_list = ['불 설정', '전구 설정', '불들 설정', '전구들 설정']  # A

time_list = ['현 시점에서', '현 상황에서'] # C '현 시점에서', '현 상황에서'
lamp_list = ['불', '전구', '불들', '전구들'] # D

# E
adverb_list = ['전반적인', '전체적인', '전체']
# G
verb_list = ['뭔지', '뭘까', '어떤지', '알려 줄래'] #  '뭔지', '뭘까', '어떤지', '알려 줄래'
# H
search_list = ['설정 값 조회', '설정 값 정보 조히', '설정 정보 값 조회', '값 설정 정보 조회']
# '설정 값 조회', '설정 값 정보 조히', '설정 정보 값 조회', '값 설정 정보 조회'

def noun_plain_sentence_generator():
    for lamp_setting_ in lamp_setting_list:
        yield lamp_setting_ + '\n'

        for search_ in search_list:
            yield lamp_setting_ + ' ' + search_ + '\n'

            for adverb_ in adverb_list:
                yield adverb_ + ' ' + lamp_setting_ + ' ' + search_ + '\n'

        for time_ in time_list:
            yield time_ + ' ' + lamp_setting_ + '\n'

            for search_ in search_list:
                yield time_ + ' ' + lamp_setting_ + ' ' + search_ + '\n'

                for adverb_ in adverb_list:
                    yield adverb_ + ' ' + time_ + ' ' + lamp_setting_ + ' ' + search_ + '\n'
                    yield time_ + ' ' + adverb_ + ' ' + lamp_setting_ + ' ' + search_ + '\n'



def verb_plain_sentence_generator():
    for verb_ in verb_list:
        for lamp_setting_ in lamp_setting_list:
            yield lamp_setting_ + ' ' + verb_ + '\n'

            for adverb_ in adverb_list:
                yield adverb_ + ' ' + lamp_setting_ + ' ' + verb_ + '\n'

            for time_ in time_list:
                yield time_ + ' ' + lamp_setting_ + ' ' + verb_ + '\n'

                for search_ in search_list:
                    yield time_ + ' ' + lamp_setting_ + ' ' + search_ + ' ' + verb_ + '\n'

                    for adverb_ in adverb_list:
                        yield adverb_ + ' ' + time_ + ' ' + lamp_setting_ + ' ' + search_ + ' ' + verb_ + '\n'
                        yield time_ + ' ' + adverb_ + ' ' + lamp_setting_ + ' ' + search_ + ' ' + verb_ + '\n'


if __name__ == '__main__':
    #
    # 1. time + subject + object
    with open(text_list[0], 'w', encoding='utf-8') as f:
        gen = noun_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    with open(text_list[1], 'w', encoding='utf-8') as f:
        gen = verb_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)
    # #
    # # 2. time + object + subject + additional
    # with open(text_list[2], 'w', encoding='utf-8') as f:
    #     gen = inversion_sentence_generator()
    #     for sentence in gen:
    #         f.write(sentence)
    #
    allQuestion = ''
    for text in text_list:
        with open(text, 'r', encoding='utf-8') as f:
            allQuestion = allQuestion + f.read()

    with open(FINAL_TEXT_TITLE, 'w', encoding='utf-8') as f:
        f.write(allQuestion)