FINAL_TEXT_TITLE = 'TV 편성표 질의 테스트.txt'
text_list = ['TV 편성표 명사 질의 테스트.txt', 'TV 편성표 동사 질의 테스트.txt']

time_list = ['다음주 오전에', '내일 오후에', '오늘 오전에'] # '다음주 오전에', '내일 오후에', '오늘 오전에'
time_list2 = [str(i) + '시의' for i in range(1, 24, 4)] # 시간을 일부만 사용하자
time_list3 = [str(i) + '시의' for i in range(1, 12, 5)] # 시간을 일부만 사용하자
time_list4 = [str(i) + '일 뒤의' for i in range(1, 7, 1)] # 시간을 일부만 사용하자
am_pm_list = ['오전', '오후']
day_list = ['화요일', '목요일', '토요일']  # '화요일', '목요일', '토요일'
adverb_list = ['에 하는', '에 할 예정인'] # '에 하는', '에 할 예정인'

object_list = ['프로들', '프로그램'] # '프로들', '프로그램'
object_list2 = ['프로', '프로그램',  '프로그램들이', '방송들이', '것들이'] # '방송이', '방송들', '프로가', '프로들', '프로그램이', '프로그램들', '것이', '것들', '프로들이', '방송', '것'
object_list3 = ['전체적으로','모두 다']  # '전체적으로'
subject_list = ['테레비에', 'TV에서']  # '테레비에', 'TV에서'
subject_list2 = ['편성 리스트', '편성표']

verb_list = ['있나', '없니', '있었지', '없었나', '있는지 보여 줘']  # '있나', '있니', '없니', '있었지', '있었니, '없었나', '있는지 보여 줘'
verb_list2 = ['띄워 줘', '보여 줄래']  # '띄워 줘', '보여 줄래',


# 현재 집에서 TV 동작 중이니? -> test
# time + subject + object


def noun_plain_sentence_generator():
    for subject_ in subject_list2:
        for time_ in time_list:
            if subject_ != '' and time_ != '':  # 중복문 만들어지는 조건이 아니면.
                yield time_ + ' ' + subject_ + '\n'
            elif time_ == '':
                yield subject_ + '\n'

    for subject_ in subject_list:
        for object_ in object_list[:-2]:
            for time_ in time_list:
                if subject_ != '' and time_ != '': # 중복문 만들어지는 조건이 아니면.
                    yield subject_ + ' ' + time_ + ' ' + object_ + '\n'
                    yield time_ + ' ' + subject_ + ' ' + object_ + '\n'
                elif time_ == '' and subject_ == '':
                    if object_ != object_list[-1]:
                        yield object_ + '\n'
                elif subject_ == '':
                    yield time_ + ' ' + object_ + '\n'
                else:
                    yield subject_ + ' ' + object_ + '\n'

            for time_ in time_list2:
                if subject_ != '' and time_ != '':  # 중복문 만들어지는 조건이 아니면.
                    yield subject_ + ' ' + time_ + ' ' + object_ + '\n'
                    yield time_ + ' ' + subject_ + ' ' + object_ + '\n'
                elif subject_ == '' and time_ != '':
                    yield time_ + ' ' + object_ + '\n'

            for time_ in time_list3:
                for am_pm in am_pm_list:
                    if subject_ != '' and time_ != '':  # 중복문 만들어지는 조건이 아니면.
                        yield subject_ + ' ' + am_pm + ' ' + time_ + ' ' + object_ + '\n'
                        yield am_pm + ' ' + time_ + ' ' + subject_ + ' ' + object_ + '\n'
                    elif subject_ == '' and time_ != '':
                        yield am_pm + ' ' + time_ + ' ' + object_ + '\n'

            for time_ in time_list4:
                if subject_ != '' and time_ != '':  # 중복문 만들어지는 조건이 아니면.
                    yield subject_ + ' ' + time_ + ' ' + object_ + '\n'
                    yield time_ + ' ' + subject_ + ' ' + object_ + '\n'
                elif subject_ == '' and time_ != '':
                    yield time_ + ' ' + object_ + '\n'


def verb_plain_sentence_generator():
    for subject_ in subject_list2: # 보여 줘, 띄워봐
        for time_ in time_list:
            for verb_ in verb_list2:
                if subject_ != '' and time_ != '':  # 중복문 만들어지는 조건이 아니면.
                    yield time_ + ' ' + subject_ + ' ' + verb_ + '\n'
                elif time_ == '':
                    yield subject_ + ' ' + verb_ + '\n'

    for verb_ in verb_list:
        for verb2_ in verb_list2:
            for object_ in object_list:
                yield object_ + ' ' + verb_ + '\n'
                for object2_ in object_list3:
                    yield object_ + ' ' + object2_ + ' ' + verb2_ + '\n'

                for adverb_ in adverb_list:
                    for time_ in time_list:
                        yield time_ + ' ' + object_ + ' ' + verb_ + '\n'
                        yield time_ + adverb_ + ' ' + object_ + ' ' + verb_ + '\n'
                        for object2_ in object_list3:
                            yield time_ + ' ' + object_ + ' ' + object2_ + ' ' + verb2_ + '\n'
                            yield time_ + adverb_ + ' ' + object_ + ' ' + object2_ + ' ' + verb2_ + '\n'

                    for time_ in time_list2:
                        yield time_ + ' ' + object_ + ' ' + verb_ + '\n'
                        yield time_ + adverb_ + ' ' + object_ + ' ' + verb_ + '\n'
                        for object2_ in object_list3:
                            yield time_ + ' ' + object_ + ' ' + object2_ + ' ' + verb2_ + '\n'
                            yield time_ + adverb_ + ' ' + object_ + ' ' + object2_ + ' ' + verb2_ + '\n'

                    for time_ in time_list3:
                        for am_pm in am_pm_list:
                            yield am_pm + ' ' + time_ + ' ' + object_ + ' ' + verb_ + '\n'
                            yield am_pm + ' ' + time_ + adverb_ + ' ' + object_ + ' ' + verb_ + '\n'
                            for object2_ in object_list3:
                                yield am_pm + ' ' + time_ + ' ' + object_ + ' ' + object2_ + ' ' + verb2_ + '\n'
                                yield am_pm + ' ' + time_ + adverb_ + ' ' + object_ + ' ' + object2_ + ' ' + verb2_ + '\n'

                    for time_ in time_list4:
                        yield time_ + ' ' + object_ + ' ' + verb_ + '\n'
                        yield time_ + adverb_ + ' ' + object_ + ' ' + verb_ + '\n'
                        for object2_ in object_list3:
                            yield time_ + ' ' + object_ + ' ' + object2_ + ' ' + verb2_ + '\n'
                            yield time_ + adverb_ + ' ' + object_ + ' ' + object2_ + ' ' + verb2_ + '\n'

                    for day_ in day_list:
                        yield day_ + ' ' + object_ + ' ' + verb_ + '\n'
                        yield day_ + adverb_ + ' ' + object_ + ' ' + verb_ + '\n'
                        for object2_ in object_list3:
                            yield day_ + ' ' + object_ + ' ' + object2_ + ' ' + verb2_ + '\n'
                            yield day_ + adverb_ + ' ' + object_ + ' ' + object2_ + ' ' + verb2_ + '\n'


def inversion_sentence_generator():
    # 여기서 도치문은 성립하지 않는다.
    pass



if __name__ == '__main__':
    #
    # 1. time + subject + object
    with open(text_list[0], 'w', encoding='utf-8') as f:
        gen = noun_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    with open(text_list[1], 'w', encoding='utf-8') as f:
        gen = verb_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)
    #
    # # 2. time + object + subject + additional, 여기는 도치문 사용안 함
    # with open(text_list[2], 'w', encoding='utf-8') as f:
    #     gen = inversion_sentence_generator()
    #     for sentence in gen:
    #         f.write(sentence)

    allQuestion = ''
    for text in text_list:
        with open(text, 'r', encoding='utf-8') as f:
            allQuestion = allQuestion + f.read()

    with open(FINAL_TEXT_TITLE, 'w', encoding='utf-8') as f:
        f.write(allQuestion)