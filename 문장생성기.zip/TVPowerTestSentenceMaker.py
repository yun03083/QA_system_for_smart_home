FINAL_TEXT_TITLE = 'TV 전원 질의 테스트.txt'
text_list = ['TV 전원 명사 질의 테스트.txt', 'TV 전원 동사 질의 테스트.txt', 'TV 전원 도치 질의 테스트.txt']
adverb_list = ['집 안에서', '누군가가', '집 안에서 누군가가']  # '집 안에서', '누군가가', '집에서 누군가가', '집 안에서 누군가가'
time_list = ['현재는', '지금은']  # '현재는', '지금은'
subject_list = ['TV를', '텔레비전']  # 'TV가', 'TV는', '텔레비전이', '텔레비전은', '테레비가', '테레비는'
subject_list2 = ['TV', '텔레비전', '테레비']
subject_list3 = ['TV']
additional_list = ['상태는', '상황은', '전원은', '전원 상태는', '전원 상황은']  # '상태는','상황은', '전원은', '전원 상태는', '전원 상황은'
verb_list = ['보고있나', '시청 중이니', '보는 중인가']  # '보고있나', '시청 중이니', '보는 중인가'
verb_list2 = ['어떤지', '어떻게 되냐']  # '어떤지', '어떻게 되냐'
verb_list3 = ['켜져있어', '꺼져있냐', '켜져있는가 꺼져있는가']


# 현재 집에서 TV 동작 중이니? -> test
# time + subject + object


def noun_plain_sentence_generator():
    for time in time_list:
        for subject__ in subject_list2:
            for additional_ in additional_list:
                if time == '':
                    yield subject__ + ' ' + additional_ + '\n'
                else:
                    yield time + ' ' + subject__ + ' ' + additional_ + '\n'
                    yield subject__ + ' ' + time + ' ' + additional_ + '\n'

        for subject__ in subject_list3:
            for verb_ in verb_list3:
                yield time + ' ' + subject__ + ' ' + verb_ + '\n'
                yield subject__ + ' ' + time + ' ' + verb_ + '\n'
                yield subject__ + ' ' + verb_ + ' ' + time + '\n'


def verb_plain_sentence_generator():
    for time in time_list:
        for subject__ in subject_list:
            for verb_ in verb_list:
                for object__ in adverb_list:
                    if object__ != '':
                        if time != '':
                            yield time + ' ' + subject__ + ' ' + object__ + ' ' + verb_ + '\n'
                            yield subject__ + ' ' + time + ' ' + object__ + ' ' + verb_ + '\n'
                            yield subject__ + ' ' + object__ + ' ' + time + ' ' + verb_ + '\n'
                        else:
                            yield subject__ + ' ' + object__ + ' ' + verb_ + '\n'

        for subject__ in subject_list2:
            for verb_ in verb_list2:
                for additional_ in additional_list:
                    if time != '':
                        yield time + ' ' + subject__ + ' ' + additional_ + ' ' + verb_ + '\n'
                        yield subject__ + ' ' + time + ' ' + additional_ + ' ' + verb_ + '\n'
                        yield subject__ + ' ' + additional_ + ' ' + time + ' ' + verb_ + '\n'
                    else:
                        yield subject__ + ' ' + additional_ + ' ' + verb_ + '\n'

        for subject__ in subject_list3:
            for verb_ in verb_list3:
                if time != '':
                    yield time + ' ' + subject__ + ' ' + verb_ + '\n'
                    yield subject__ + ' ' + time + ' ' + verb_ + '\n'
                else:
                    yield subject__ + ' ' + verb_ + '\n'


def inversion_sentence_generator():
    for time in time_list:
        for object_ in adverb_list:
            if object_ != '':
                for subject_ in subject_list:
                    for verb_ in verb_list:
                        if time == '':  # non additional
                            yield object_ + ' ' + subject_ + ' ' + verb_ + '\n'
                        else:
                            yield time + ' ' + object_ + ' ' + subject_ + ' ' + verb_ + '\n'
                            yield object_ + ' ' + time + ' ' + subject_ + ' ' + verb_ + '\n'
                            yield object_ + ' ' + subject_ + ' ' + time + ' ' + verb_ + '\n'


if __name__ == '__main__':
    # 1. time + subject + object
    with open(text_list[0], 'w', encoding='utf-8') as f:
        gen = noun_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    with open(text_list[1], 'w', encoding='utf-8') as f:
        gen = verb_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    # 2. time + object + subject + additional
    with open(text_list[2], 'w', encoding='utf-8') as f:
        gen = inversion_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    allQuestion = ''
    for text in text_list:
        with open(text, 'r', encoding='utf-8') as f:
            allQuestion = allQuestion + f.read()

    with open(FINAL_TEXT_TITLE, 'w', encoding='utf-8') as f:
        f.write(allQuestion)


