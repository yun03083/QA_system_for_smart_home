FINAL_TEXT_TITLE = 'TV 전원 질의.txt'
text_list = ['TV 전원 명사 질의.txt', 'TV 전원 동사 질의.txt', 'TV 전원 도치 질의.txt']
adverb_list = ['', '집에서', '누군가', '집에서 누군가', '집안에', '집안에 누군가']  # 집 안에서, 누군가가, 집에서 누군가가, 집 안에서 누군가가
time_list = ['', '현재', '지금']  # 현재는, 지금은
subject_list = ['TV', 'TV를', '텔레비전을', '테레비를']  # TV가, TV는, 텔레비전이, 텔레비전은, 테레비가, 테리비는
subject_list2 = ['TV의', '텔레비전의', '테레비의']
subject_list3 = ['TV가']
additional_list = ['상태', '상황', '전원', '전원 상태', '전원 상황']  # 상태는, 상황은, 전원은, 전원 상태는, 전원 상황은
verb_list = ['봐', '보냐', '보니', '보고있냐', '보고있니', \
             '시청 중이냐', '시청 중이야', '시청 중인가', '시청 중인지', \
             '보는 중이야', '보는 중이냐', '보고 있어', '보는 중인지']  # '보고있나', '시청 중이니', '보는 중인가'
verb_list2 = ['어때', '어떠니', '어떠냐', '어떻냐', '어떤가', '어떻게 되니', '어떻게 되지']  # '어떤지', '어떻게 되냐'
verb_list3 = ['켜져있니', '켜져있냐', '켜져있을까', '꺼져있어', '꺼져있니', '꺼져있을까',  '켜져있니 꺼져있니', '켜져있나 꺼져있나', '켜져있을까 꺼져있을까']


# 현재 집에서 TV 동작 중이니? -> test
# time + subject + object


def noun_plain_sentence_generator():
    for time in time_list:
        for subject__ in subject_list2:
            for additional_ in additional_list:
                if time == '':
                    yield subject__ + ' ' + additional_ + '\n'
                else:
                    yield time + ' ' + subject__ + ' ' + additional_ + '\n'
                    yield subject__ + ' ' + time + ' ' + additional_ + '\n'

        for subject__ in subject_list3:
            for verb_ in verb_list3:
                if time != '':
                    yield subject__ + ' ' + verb_ + ' ' + time + '\n'


def verb_plain_sentence_generator():
    for time in time_list:
        for subject__ in subject_list:
            for verb_ in verb_list:
                for adverb_ in adverb_list:
                    if adverb_ != '':
                        if time != '':
                            yield time + ' ' + subject__ + ' ' + adverb_ + ' ' + verb_ + '\n'
                            yield subject__ + ' ' + time + ' ' + adverb_ + ' ' + verb_ + '\n'
                            yield subject__ + ' ' + adverb_ + ' ' + time + ' ' + verb_ + '\n'
                        else:
                            yield subject__ + ' ' + adverb_ + ' ' + verb_ + '\n'

        for subject__ in subject_list2:
            for verb_ in verb_list2:
                for additional_ in additional_list:
                    if time != '':
                        yield time + ' ' + subject__ + ' ' + additional_ + ' ' + verb_ + '\n'
                        yield subject__ + ' ' + time + ' ' + additional_ + ' ' + verb_ + '\n'
                        yield subject__ + ' ' + additional_ + ' ' + time + ' ' + verb_ + '\n'
                    else:
                        yield subject__ + ' ' + additional_ + ' ' + verb_ + '\n'

        for subject__ in subject_list3:
            for verb_ in verb_list3:
                if time != '':
                    yield time + ' ' + subject__ + ' ' + verb_ + '\n'
                    yield subject__ + ' ' + time + ' ' + verb_ + '\n'
                else:
                    yield subject__ + ' ' + verb_ + '\n'


def inversion_sentence_generator():
    for time in time_list:
        for adverb_ in adverb_list:
            if adverb_ != '':
                for subject_ in subject_list:
                    for verb_ in verb_list:
                        if time == '':  # non additional
                            yield adverb_ + ' ' + subject_ + ' ' + verb_ + '\n'
                        else:
                            yield time + ' ' + adverb_ + ' ' + subject_ + ' ' + verb_ + '\n'
                            yield adverb_ + ' ' + time + ' ' + subject_ + ' ' + verb_ + '\n'
                            yield adverb_ + ' ' + subject_ + ' ' + time + ' ' + verb_ + '\n'


if __name__ == '__main__':
    # 1. time + subject + object
    with open(text_list[0], 'w', encoding='utf-8') as f:
        gen = noun_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    with open(text_list[1], 'w', encoding='utf-8') as f:
        gen = verb_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    # 2. time + object + subject + additional
    with open(text_list[2], 'w', encoding='utf-8') as f:
        gen = inversion_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    allQuestion = ''
    for text in text_list:
        with open(text, 'r', encoding='utf-8') as f:
            allQuestion = allQuestion + f.read()

    with open(FINAL_TEXT_TITLE, 'w', encoding='utf-8') as f:
        f.write(allQuestion)


