FINAL_TEXT_TITLE = '전구 밝기 질의.txt'
text_list = ['전구 밝기 명사 질의.txt', '전구 밝기 동사 질의.txt']

light_list = ['밝기', '밝은 정도', '밝은 세기', '세기'] # G
lamp_list = ['등', '불', '전구', '전구 불', '전구 등', '등불']  # A

search_list = ['조회', '정보', '정보 조회'] # I

time_list = ['지금', '현재', '현 시점에서', '현 상황에서'] # '현재 시점에서', '현재 상황에서'

target_list = ['집에', '집안에', '각각의', '각']  # B

# E
verb_list = ['밝아', '밝니', '밝냐', '밝은가', '밝은지', '밝지', '어두운지'] # '밝은지 알려 줄래', '밝은지 알려 줘', '어두운가'
# H
verb_list2 = ['어때', '어떻냐', '어떠한가', '어떠한지', '어떻지', '어떤 정도지', '어느 수준이지'] # '어떠니', '어떤 상태이지', '어느 상태이지'

adverb_list = ['얼마나', '얼만큼', '어느 정도로'] # D


def noun_plain_sentence_generator():
    for lamp_ in lamp_list:
        for light_ in light_list:
            yield lamp_ + ' ' + light_ + '\n'
            yield lamp_ + '의 ' + light_ + '\n'

            for search_ in search_list:
                yield lamp_ + ' ' + light_ + ' ' + search_ + '\n'
                yield lamp_ + '의 ' + light_ + ' ' + search_ + '\n'

                for target_ in target_list:
                    yield target_ + ' ' + lamp_ + ' ' + light_ + '\n'
                    yield target_ + ' ' + lamp_ + '의 ' + light_ + '\n'
                    yield target_ + ' ' + lamp_ + ' ' + light_ + ' ' + search_ + '\n'
                    yield target_ + ' ' + lamp_ + '의 ' + light_ + ' ' + search_ + '\n'

                    for time_ in time_list:
                        yield time_ + ' ' + lamp_ + ' ' + light_ + '\n'
                        yield time_ + ' ' + lamp_ + '의 ' + light_ + '\n'
                        yield time_ + ' ' + target_ + ' ' + lamp_ + ' ' + light_ + '\n'
                        yield time_ + ' ' + target_ + ' ' + lamp_ + '의 ' + light_ + '\n'
                        yield time_ + ' ' + lamp_ + ' ' + light_ + ' ' + search_ + '\n'
                        yield time_ + ' ' + lamp_ + '의 ' + light_ + ' ' + search_ + '\n'
                        yield time_ + ' ' + target_ + ' ' + lamp_ + ' ' + light_ + ' ' + search_ + '\n'
                        yield time_ + ' ' + target_ + ' ' + lamp_ + '의 ' + light_ + ' ' + search_ + '\n'


def verb_plain_sentence_generator():
    for lamp_ in lamp_list:
        for verb_ in verb_list:
            for adverb_ in adverb_list:
                yield lamp_ + ' ' + adverb_ + ' ' + verb_ + '\n'
                yield lamp_ + '은 ' + adverb_ + ' ' + verb_ + '\n'

                for target_ in target_list:
                    yield target_ + ' ' + lamp_ + ' ' + adverb_ + ' ' + verb_ + '\n'
                    yield target_ + ' ' + lamp_ + '은 ' + adverb_ + ' ' + verb_ + '\n'

                    for time_ in time_list:
                        yield time_ + ' ' + lamp_ + ' ' + adverb_ + ' ' + verb_ + '\n'
                        yield time_ + ' ' + lamp_ + '은 ' + adverb_ + ' ' + verb_ + '\n'
                        yield time_ + ' ' + target_ + ' ' + lamp_ + ' ' + adverb_ + ' ' + verb_ + '\n'
                        yield time_ + ' ' + target_ + ' ' + lamp_ + '은 ' + adverb_ + ' ' + verb_ + '\n'

        for verb_ in verb_list2:
            for adverb_ in light_list:
                yield lamp_ + ' ' + adverb_ + ' ' + verb_ + '\n'
                yield lamp_ + '의 ' + adverb_ + ' ' + verb_ + '\n'

            for target_ in target_list:
                yield target_ + ' ' + lamp_ + ' ' + adverb_ + ' ' + verb_ + '\n'
                yield target_ + ' ' + lamp_ + '의 ' + adverb_ + ' ' + verb_ + '\n'

                for time_ in time_list:
                    yield time_ + ' ' + lamp_ + ' ' + adverb_ + ' ' + verb_ + '\n'
                    yield time_ + ' ' + lamp_ + '의 ' + adverb_ + ' ' + verb_ + '\n'
                    yield time_ + ' ' + target_ + ' ' + lamp_ + ' ' + adverb_ + ' ' + verb_ + '\n'
                    yield time_ + ' ' + target_ + ' ' + lamp_ + '의 ' + adverb_ + ' ' + verb_ + '\n'




if __name__ == '__main__':
    #
    # 1. time + subject + object
    with open(text_list[0], 'w', encoding='utf-8') as f:
        gen = noun_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    with open(text_list[1], 'w', encoding='utf-8') as f:
        gen = verb_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)
    # #
    # # 2. time + object + subject + additional
    # with open(text_list[2], 'w', encoding='utf-8') as f:
    #     gen = inversion_sentence_generator()
    #     for sentence in gen:
    #         f.write(sentence)
    #
    allQuestion = ''
    for text in text_list:
        with open(text, 'r', encoding='utf-8') as f:
            allQuestion = allQuestion + f.read()

    with open(FINAL_TEXT_TITLE, 'w', encoding='utf-8') as f:
        f.write(allQuestion)