FINAL_TEXT_TITLE = '전구 위치 밝기 질의 테스트.txt'
text_list = ['전구 위치 밝기 명사 질의 테스트.txt', '전구 위치 밝기 동사 질의 테스트.txt']

light_list = ['밝기', '밝은 정도', '밝은 세기', '세기'] # G
lamp_list = ['전구 불', '전구 등', '등불']  # A

search_list = ['조회', '정보', '정보 조회'] # I

time_list = ['현 시점에서', '현 상황에서'] #

location_list = ['거실', '안방', '화장실', '작은방', '큰방', '주방', '다목적실', '베란다']  # B

# E
verb_list = ['밝은지 알려 줄래', '밝은지 알려 줘', '어두운가'] # '밝니', '밝냐', '밝은지 알려 줄래', '밝은지 알려 줘', '어두운가'
# H
verb_list2 = ['어떻지', '어떻냐', '어떠니', '어떤 상태이지'] # '어떻지', '어떻냐','어떠니', '어떤 상태이지', '어느 상태이지'

adverb_list = ['얼마나', '얼만큼', '어느 정도로'] # D


def noun_plain_sentence_generator():
    for lamp_ in lamp_list:
        for light_ in light_list:
            for search_ in search_list:
                for target_location_ in location_list:
                    yield target_location_ + ' ' + lamp_ + ' ' + light_ + '\n'
                    yield target_location_ + ' ' + lamp_ + '의 ' + light_ + '\n'
                    yield target_location_ + ' ' + lamp_ + ' ' + light_ + ' ' + search_ + '\n'
                    yield target_location_ + ' ' + lamp_ + '의 ' + light_ + ' ' + search_ + '\n'

                    for time_ in time_list:
                        yield time_ + ' ' + lamp_ + ' ' + light_ + '\n'
                        yield time_ + ' ' + lamp_ + '의 ' + light_ + '\n'
                        yield time_ + ' ' + target_location_ + ' ' + lamp_ + ' ' + light_ + '\n'
                        yield time_ + ' ' + target_location_ + ' ' + lamp_ + '의 ' + light_ + '\n'
                        yield time_ + ' ' + lamp_ + ' ' + light_ + ' ' + search_ + '\n'
                        yield time_ + ' ' + lamp_ + '의 ' + light_ + ' ' + search_ + '\n'
                        yield time_ + ' ' + target_location_ + ' ' + lamp_ + ' ' + light_ + ' ' + search_ + '\n'
                        yield time_ + ' ' + target_location_ + ' ' + lamp_ + '의 ' + light_ + ' ' + search_ + '\n'


def verb_plain_sentence_generator():
    for lamp_ in lamp_list:
        for verb_ in verb_list:
            for adverb_ in adverb_list:
                for target_location_ in location_list:
                    yield target_location_ + ' ' + lamp_ + ' ' + adverb_ + ' ' + verb_ + '\n'
                    yield target_location_ + ' ' + lamp_ + '은 ' + adverb_ + ' ' + verb_ + '\n'

                    for time_ in time_list:
                        yield time_ + ' ' + target_location_ + ' ' + lamp_ + ' ' + adverb_ + ' ' + verb_ + '\n'
                        yield time_ + ' ' + target_location_ + ' ' + lamp_ + '은 ' + adverb_ + ' ' + verb_ + '\n'

        for verb_ in verb_list2:
            for adverb_ in light_list:
                for target_location_ in location_list:
                    yield target_location_ + ' ' + lamp_ + ' ' + adverb_ + ' ' + verb_ + '\n'
                    yield target_location_ + ' ' + lamp_ + '의 ' + adverb_ + ' ' + verb_ + '\n'

                    for time_ in time_list:
                        yield time_ + ' ' + target_location_ + ' ' + lamp_ + ' ' + adverb_ + ' ' + verb_ + '\n'
                        yield time_ + ' ' + target_location_ + ' ' + lamp_ + '의 ' + adverb_ + ' ' + verb_ + '\n'




if __name__ == '__main__':
    #
    # 1. time + subject + object
    with open(text_list[0], 'w', encoding='utf-8') as f:
        gen = noun_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)

    with open(text_list[1], 'w', encoding='utf-8') as f:
        gen = verb_plain_sentence_generator()
        for sentence in gen:
            f.write(sentence)
    # #
    # # 2. time + object + subject + additional
    # with open(text_list[2], 'w', encoding='utf-8') as f:
    #     gen = inversion_sentence_generator()
    #     for sentence in gen:
    #         f.write(sentence)
    #
    allQuestion = ''
    for text in text_list:
        with open(text, 'r', encoding='utf-8') as f:
            allQuestion = allQuestion + f.read()

    with open(FINAL_TEXT_TITLE, 'w', encoding='utf-8') as f:
        f.write(allQuestion)